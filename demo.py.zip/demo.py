class Book:
    def __init__(self, title, author, genre, copies):
        pass
    
    def add_to_waitlist(self, customer):
        pass
    
    def remove_from_waitlist(self):
        pass;
    
class Customer:
    def __init__(self, first_name, last_name, library_card):
        pass
    
class Library:
    def __init__(self):
        pass
    
    def add_customer(self, customer):
       pass

    def remove_customer(self, customer):
        pass
    
    def checkout_book(self, book_title, customer_card):
        pass
    

    def return_book(self, book_title, customer_card):
        pass
    
    def calculate_late_fees(self, book_title):
        pass
    
    
if __name__ == "__main__":
    pass